# ews_hello

This cookbook configures and deploys a simple application, hello-ews. The purpose is to provide a tangible demo/showcase application for standards and conventions for building simple apps at Early Warning Services.

This documentation is work in progress.

