#
# Cookbook Name:: ews_hello
#
# Copyright (c) 2016 Early Warning Services, LLC. All Rights Reserved.
#
# Internal use only. Confidential and proprietary.
# You may not disclose, copy or distribute this material for any
# purpose in any medium without the expressed written consent of
# Early Warning.
#

###############
# User attributes
###############
default['ews_hello']['user'] = 'online'
default['ews_hello']['uid'] = '300'
default['ews_hello']['gid'] = '300'
default['ews_hello']['group'] = 'online'

default['ews_hello']['log_folder'] = '/var/log/HLO'
default['ews_hello']['greeting_location'] = '/home/online/greeting.properties'

###############
# RPM attributes
###############
default['ews_hello']['package_location'] =
  'https://artifactory.ews.int/artifactory/yum-local/hello-ews/devint/rpms'
default['ews_hello']['rpm_package'] = 'hello-ews'

###############
# Version Management
###############
default['ews_hello']['version'] = ''
# the track attribute controls the environment that
# avlo biz runs under. it allows to dynamically create rpm version attributes
# such as
# node['ews_hello_dev1']['version'] and
# node['ews_hello_dev2']['version']
default['ews_hello']['track'] = ''

###############
# Service Management
###############
default['ews_hello']['init_name'] = 'hello-ews'

###############
# Properties File (config)
################
default['ews_hello']['properties_loc'] = '/ews/opt/hello-ews/configuration'
default['ews_hello']['properties_databag']['name'] = 'ews_hello'
default['ews_hello']['properties_databag']['item'] = 'dev'
