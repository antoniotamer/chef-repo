#
# Cookbook Name:: ews_hello
# Recipe:: configure
#
# Copyright (c) 2016 Early Warning Services, LLC. All Rights Reserved.
#
# Internal use only. Confidential and proprietary.
# You may not disclose, copy or distribute this material for any
# purpose in any medium without the expressed written consent of
# Early Warning.

template "/tmp/greeting.properties" do
  owner node['ews_hello']['user']
  group node['ews_hello']['group']
  source 'greeting.properties.erb'
  mode '0660'
  action :create
end
