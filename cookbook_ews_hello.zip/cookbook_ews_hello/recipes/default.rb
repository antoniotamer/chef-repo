#
# Cookbook Name:: ews_hello
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
include_recipe 'ews_hello::pre_install'
include_recipe 'ews_hello::install'
include_recipe 'ews_hello::configure'
