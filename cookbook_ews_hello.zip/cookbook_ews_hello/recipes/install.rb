#
# Cookbook Name:: ews_hello
# Recipe:: install
#
# Copyright (c) 2016 Early Warning Services, LLC. All Rights Reserved.
#
# Internal use only. Confidential and proprietary.
# You may not disclose, copy or distribute this material for any
# purpose in any medium without the expressed written consent of
# Early Warning.

cookbook_file "/home/#{node['ews_hello']['user']}/spring-boot-autoconfigure.jar" do
  source 'spring-boot-autoconfigure.jar'
  owner node['ews_hello']['user']
  group node['ews_hello']['group']
  mode '0755'
  action :create
end
